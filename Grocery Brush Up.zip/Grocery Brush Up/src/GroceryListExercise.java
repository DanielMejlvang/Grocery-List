import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class GroceryListExercise {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(new File("itemOrder.txt"));
        GroceryList list = new GroceryList();
        addFromFile(list, input);

        PrintStream output = new PrintStream(new File("itemOrder.txt"));
        list.printToFile(output);
        list.printList();
    }

    public static void addFromFile(GroceryList list, Scanner input) {
        while (input.hasNextLine()) {
            String line = input.nextLine();
            String[] tokens = line.split(",");
            new ItemOrder(tokens[0], Integer.parseInt(tokens[1]), Double.parseDouble(tokens[2]), list);
        }
    }
}
